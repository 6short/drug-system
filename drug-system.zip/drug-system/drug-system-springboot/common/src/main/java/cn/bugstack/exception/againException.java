package cn.bugstack.exception;

public class againException extends BaseException {

    public againException(String message) {
        super(message);
    }
}
