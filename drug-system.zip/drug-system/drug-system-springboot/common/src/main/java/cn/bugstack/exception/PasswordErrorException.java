package cn.bugstack.exception;

public class PasswordErrorException extends BaseException {
    public PasswordErrorException(String message) {

        super(message);
    }
}
