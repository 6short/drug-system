package cn.bugstack.constant;

public class MessageConstant {

    public static final String PHONE_NOT_FOUND = "号码不存在";
    public static final String PASSWORD_ERROR = "密码错误";
    public static final String AGAIN_ADMIN = "用户已存在";
}
