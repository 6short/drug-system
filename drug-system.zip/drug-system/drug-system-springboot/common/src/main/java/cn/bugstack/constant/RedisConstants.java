package cn.bugstack.constant;

public class RedisConstants {

    public static final String SIGN_EMAIL_KEY = "sign:email";

    public static final Long SIGN_EAMIL_TTL = 2L;
}
