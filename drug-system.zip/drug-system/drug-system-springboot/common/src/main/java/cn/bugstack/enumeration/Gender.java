package cn.bugstack.enumeration;

public enum Gender {
    男,
    女
}
