package cn.bugstack.enumeration;

public enum OperationType {

    UPDATE, // 更新操作
    INSERT, // 插入操作
    REG     // 注册操作
}
