package cn.bugstack.result;

public class PageResult {
}
