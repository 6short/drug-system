package cn.bugstack.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


//@EnableWebSecurity
//@Configuration
//@Slf4j
//public class WebMvcConfiguration {


//}
