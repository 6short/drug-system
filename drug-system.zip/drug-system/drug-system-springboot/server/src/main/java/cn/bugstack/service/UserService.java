package cn.bugstack.service;

import org.apache.catalina.User;

public interface UserService {

    User getUser(Integer id);
}
