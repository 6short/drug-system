package cn.bugstack.dto;

import lombok.Data;

@Data
public class AdminSignEmailDTO {
    private String eamil;
}
