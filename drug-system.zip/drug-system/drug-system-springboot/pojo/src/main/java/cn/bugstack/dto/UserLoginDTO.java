package cn.bugstack.dto;

//账号密码的登陆方式
public class UserLoginDTO {

}
